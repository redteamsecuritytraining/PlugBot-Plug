-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 10, 2015 at 07:33 AM
-- Server version: 5.5.43
-- PHP Version: 5.4.39-0+deb7u2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_plugbot_client`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblApp`
--

CREATE TABLE IF NOT EXISTS `tblApp` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `app_botkey` varchar(255) NOT NULL,
  `app_random` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_dir` varchar(255) NOT NULL,
  `app_exec` varchar(255) NOT NULL,
  `app_interactive` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblBot`
--

CREATE TABLE IF NOT EXISTS `tblBot` (
  `bot_id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_key` varchar(255) NOT NULL,
  `bot_privatekey` varchar(255) NOT NULL,
  `bot_name` varchar(255) NOT NULL,
  PRIMARY KEY (`bot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblDropZone`
--

CREATE TABLE IF NOT EXISTS `tblDropZone` (
  `dropzone_id` int(11) NOT NULL AUTO_INCREMENT,
  `dropzone_status` int(11) NOT NULL,
  `dropzone_url` varchar(255) NOT NULL,
  `dropzone_tor` int(11) NOT NULL,
  PRIMARY KEY (`dropzone_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblDropZone`
--

INSERT INTO `tblDropZone` (`dropzone_id`, `dropzone_status`, `dropzone_url`, `dropzone_tor`) VALUES
(1, 1, 'http://localhost/pb', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblJob`
--

CREATE TABLE IF NOT EXISTS `tblJob` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_status` int(11) NOT NULL,
  `job_botkey` varchar(255) NOT NULL,
  `job_random` varchar(255) NOT NULL,
  `job_app_random` varchar(255) NOT NULL,
  `job_name` varchar(255) NOT NULL,
  `job_command` varchar(255) NOT NULL,
  `job_output` longtext,
  `job_updateid` int(11) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblLog`
--

CREATE TABLE IF NOT EXISTS `tblLog` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_botkey` varchar(255) NOT NULL,
  `log_date` datetime NOT NULL,
  `log_type` int(11) NOT NULL,
  `log_action` varchar(255) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblPlugBot`
--

CREATE TABLE IF NOT EXISTS `tblPlugBot` (
  `plugbot_id` int(11) NOT NULL,
  `plugbot_version` varchar(255) NOT NULL,
  `plugbot_appname` varchar(255) NOT NULL,
  `plugbot_legalese` varchar(255) NOT NULL,
  `plugbot_credit` varchar(255) NOT NULL,
  PRIMARY KEY (`plugbot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblPlugBot`
--

INSERT INTO `tblPlugBot` (`plugbot_id`, `plugbot_version`, `plugbot_appname`, `plugbot_legalese`, `plugbot_credit`) VALUES
(0, '0.89', 'PlugBot', 'PlugBot by <a href="http://www.redteamsecure.com">RedTeam Security</a> is licensed under a <a href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.', 'Jeremiah Talamantes, RedTeam Security');

-- --------------------------------------------------------

--
-- Table structure for table `tblUser`
--

CREATE TABLE IF NOT EXISTS `tblUser` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblUser`
--

INSERT INTO `tblUser` (`user_id`, `user_username`, `user_password`) VALUES
(1, 'admin', '76c0796cbc9132a56fb110ebfafa8bd673805780');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
